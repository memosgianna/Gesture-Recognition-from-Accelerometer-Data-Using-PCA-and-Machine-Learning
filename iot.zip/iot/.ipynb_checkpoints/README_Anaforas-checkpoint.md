# Gesture Recognition Project

This repository contains code and notebooks to perform gesture recognition using accelerometer data. It includes data acquisition, processing, dimensionality reduction, model training, and evaluation.

The way we perfomed the gestures was clear and simple. We recorded 10 sets of 10 iterations for the letters A and L seperately.

---

##  Notebooks Overview

### 1. `aiot_dataset_creation.ipynb`

- Connects to the database
- Uploads raw CSV files containing gesture data
- Ensures data availability for subsequent processing

### 2. `aiot_project.ipynb`

- Loads the uploaded gesture data from the database
- Visualizes raw data (time-domain, 3D plots)
- Applies preprocessing: filtering, segmentation, flattening
- Performs train/test splitting
- Applies data scaling (Min-Max normalization or Standardization)
- Performs PCA dimensionality reduction (2 and 3 components)
- Trains simple classifiers (Logistic Regression)
- Evaluates classifiers using accuracy, F1-score, and confusion matrix

---

##  Running the Project

### Prerequisites
- Python 3.8+
- MongoDB installed
- Jupyter Notebook or Jupyter Lab installed
- Required Python libraries (install via `requirements.txt` or pip):

### Step 1 - Docker && Containers
- run `sudo dockerd` to create a docker
- run `./start_project.sh` to start the mongo and jupyter container

### Step 2 - Install the requirements
- run `pip install -r requirements.txt` in an empty cell in jypter

### Configuration of the database
- change the above based on your configuration : 
    # DB Connection with the uri (host)
    client: `mongodb://mymongo:27017`

    # db name
    db: `aiot_course`

    # db collection
    col: `gesture_data`

### Run the project
- run the `aiot_dataset_creation.ipynb` and then the `aiot_project.ipynb`